package com.modnmetl.modnvote.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.Objects;

/**
 * DAO for privacy-safe participation tracking.
 *
 * Participation records prove inclusion and enforce one vote per derived
 * participation token, while never storing vote content.
 *
 * IP hashes are stored only in the participation layer so the plugin can
 * apply duplicate-prevention heuristics without linking identities to ballots.
 */
public final class ParticipationRecordDao {

    private final DatabaseManager databaseManager;

    public ParticipationRecordDao(DatabaseManager databaseManager) {
        this.databaseManager = Objects.requireNonNull(databaseManager, "databaseManager");
    }

    public long insertParticipationRecord(Connection connection,
                                          long pollId,
                                          String participationTokenHash,
                                          Instant submittedAt,
                                          String participationReceiptHash,
                                          String clientPlatform,
                                          String ipHash,
                                          String floodgateId) throws SQLException {
        Objects.requireNonNull(connection, "connection");
        Objects.requireNonNull(participationTokenHash, "participationTokenHash");
        Objects.requireNonNull(submittedAt, "submittedAt");
        Objects.requireNonNull(participationReceiptHash, "participationReceiptHash");
        Objects.requireNonNull(clientPlatform, "clientPlatform");

        String sql = """
                INSERT INTO participation_records (
                    poll_id,
                    participation_token_hash,
                    submitted_at,
                    participation_receipt_hash,
                    client_platform,
                    ip_hash,
                    floodgate_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """;

        try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, pollId);
            ps.setString(2, participationTokenHash);
            ps.setLong(3, submittedAt.toEpochMilli());
            ps.setString(4, participationReceiptHash);
            ps.setString(5, clientPlatform);

            if (ipHash != null) {
                ps.setString(6, ipHash);
            } else {
                ps.setNull(6, java.sql.Types.VARCHAR);
            }

            if (floodgateId != null) {
                ps.setString(7, floodgateId);
            } else {
                ps.setNull(7, java.sql.Types.VARCHAR);
            }

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getLong(1);
                }
            }
        }

        throw new SQLException("Failed to insert participation record; no generated key returned.");
    }

    public boolean existsParticipationForPollAndTokenHash(Connection connection,
                                                          long pollId,
                                                          String participationTokenHash) throws SQLException {
        Objects.requireNonNull(connection, "connection");
        Objects.requireNonNull(participationTokenHash, "participationTokenHash");

        String sql = """
                SELECT 1
                FROM participation_records
                WHERE poll_id = ?
                  AND participation_token_hash = ?
                LIMIT 1
                """;

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, pollId);
            ps.setString(2, participationTokenHash);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public boolean existsParticipationForPollAndIpHash(Connection connection,
                                                       long pollId,
                                                       String ipHash) throws SQLException {
        Objects.requireNonNull(connection, "connection");
        Objects.requireNonNull(ipHash, "ipHash");

        String sql = """
                SELECT 1
                FROM participation_records
                WHERE poll_id = ?
                  AND ip_hash = ?
                LIMIT 1
                """;

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, pollId);
            ps.setString(2, ipHash);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public String findParticipationReceiptHashByPollAndTokenHash(long pollId, String participationTokenHash) throws SQLException {
        Objects.requireNonNull(participationTokenHash, "participationTokenHash");

        String sql = """
                SELECT participation_receipt_hash
                FROM participation_records
                WHERE poll_id = ?
                  AND participation_token_hash = ?
                LIMIT 1
                """;

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, pollId);
            ps.setString(2, participationTokenHash);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("participation_receipt_hash");
                }
            }
        }

        return null;
    }

    public java.util.List<String> findParticipationReceiptHashesByPollId(long pollId) throws SQLException {
        String sql = """
            SELECT participation_receipt_hash
            FROM participation_records
            WHERE poll_id = ?
            ORDER BY participation_id ASC
            """;

        try (Connection connection = databaseManager.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, pollId);

            try (ResultSet rs = ps.executeQuery()) {
                java.util.List<String> out = new java.util.ArrayList<>();
                while (rs.next()) {
                    out.add(rs.getString("participation_receipt_hash"));
                }
                return out;
            }
        }
    }
}
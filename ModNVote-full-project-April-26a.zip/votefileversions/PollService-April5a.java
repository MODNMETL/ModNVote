package com.modnmetl.modnvote.service;

import com.modnmetl.modnvote.api.PollStatus;
import com.modnmetl.modnvote.api.PollType;
import com.modnmetl.modnvote.domain.Poll;
import com.modnmetl.modnvote.domain.PollOption;
import com.modnmetl.modnvote.platform.PlatformAdapter;
import com.modnmetl.modnvote.storage.AuditEventDao;
import com.modnmetl.modnvote.storage.DatabaseManager;
import com.modnmetl.modnvote.storage.PollDao;
import com.modnmetl.modnvote.storage.PollOptionDao;

import java.security.SecureRandom;
import java.sql.Connection;
import java.time.Instant;
import java.util.HexFormat;
import java.util.List;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * Service layer for poll lifecycle operations.
 */
public final class PollService {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final DatabaseManager databaseManager;
    private final PlatformAdapter platformAdapter;
    private final Logger logger;
    private final PollDao pollDao;
    private final PollOptionDao pollOptionDao;
    private final AuditEventDao auditEventDao;

    public PollService(DatabaseManager databaseManager,
                       PlatformAdapter platformAdapter,
                       Logger logger) {
        this.databaseManager = Objects.requireNonNull(databaseManager, "databaseManager");
        this.platformAdapter = Objects.requireNonNull(platformAdapter, "platformAdapter");
        this.logger = Objects.requireNonNull(logger, "logger");
        this.pollDao = new PollDao(databaseManager);
        this.pollOptionDao = new PollOptionDao(databaseManager);
        this.auditEventDao = new AuditEventDao(databaseManager);
    }

    public boolean isInitialized() {
        return true;
    }

    public String getStatusSummary() {
        return "PollService ready";
    }

    public List<Poll> listPolls() throws PollServiceException {
        try {
            return pollDao.findAllPolls();
        } catch (Exception e) {
            throw new PollServiceException("Failed to load polls", e);
        }
    }

    public Poll findPollById(long pollId) throws PollServiceException {
        try {
            return pollDao.findPollById(pollId);
        } catch (Exception e) {
            throw new PollServiceException("Failed to load poll #" + pollId, e);
        }
    }

    public long createSeedBreedPoll(String createdBy) throws PollServiceException {
        try {
            String slug = "breed-of-the-month-" + Instant.now().toEpochMilli();

            if (pollDao.pollExistsBySlug(slug)) {
                throw new IllegalStateException("Generated slug already exists: " + slug);
            }

            Poll poll = new Poll(
                    0L,
                    slug,
                    "Breed of the Month",
                    "Rank the nominated horse breeds in order of preference.",
                    PollType.RANKED_SINGLE_WINNER,
                    PollStatus.DRAFT,
                    null,
                    null,
                    6,
                    1,
                    true,
                    true,
                    generateParticipationSecret()
            );

            List<PollOption> options = List.of(
                    new PollOption(0L, 0L, "arabian", "Arabian", "Elegant, fast, and refined.", 0),
                    new PollOption(0L, 0L, "shire", "Shire", "Large, powerful, and steady.", 1),
                    new PollOption(0L, 0L, "mustang", "Mustang", "Hardy, agile, and spirited.", 2),
                    new PollOption(0L, 0L, "friesian", "Friesian", "Striking black coat and noble bearing.", 3),
                    new PollOption(0L, 0L, "andalusian", "Andalusian", "Strong, responsive, and graceful.", 4),
                    new PollOption(0L, 0L, "clydesdale", "Clydesdale", "Heavy draft strength with calm temperament.", 5)
            );

            try (Connection connection = databaseManager.getConnection()) {
                connection.setAutoCommit(false);
                try {
                    long pollId = pollDao.insertPoll(connection, poll, createdBy, "UUID_AND_IP_HEURISTIC", "{}");
                    pollOptionDao.insertOptions(connection, pollId, options);
                    auditEventDao.insertPollEvent(
                            connection,
                            pollId,
                            "POLL_CREATED",
                            "actor=" + createdBy + ";slug=" + poll.slug() + ";status=" + poll.status().name()
                    );
                    connection.commit();
                    return pollId;
                } catch (Exception e) {
                    connection.rollback();
                    throw e;
                } finally {
                    connection.setAutoCommit(true);
                }
            }
        } catch (Exception e) {
            throw new PollServiceException("Failed to create seed breed poll", e);
        }
    }

    public void openPoll(long pollId, String actor) throws PollServiceException {
        try {
            Poll poll = pollDao.findPollById(pollId);
            if (poll == null) {
                throw new PollServiceException("Poll #" + pollId + " does not exist.");
            }
            if (poll.status() != PollStatus.DRAFT) {
                throw new PollServiceException("Poll #" + pollId + " is not in DRAFT state.");
            }

            try (Connection connection = databaseManager.getConnection()) {
                connection.setAutoCommit(false);
                try {
                    pollDao.updatePollStatus(connection, pollId, PollStatus.OPEN);
                    auditEventDao.insertPollEvent(
                            connection,
                            pollId,
                            "POLL_OPENED",
                            "actor=" + actor + ";poll_id=" + pollId + ";from=DRAFT;to=OPEN"
                    );
                    connection.commit();
                } catch (Exception e) {
                    connection.rollback();
                    throw e;
                } finally {
                    connection.setAutoCommit(true);
                }
            }
        } catch (PollServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new PollServiceException("Failed to open poll #" + pollId, e);
        }
    }

    public void closePoll(long pollId, String actor) throws PollServiceException {
        try {
            Poll poll = pollDao.findPollById(pollId);
            if (poll == null) {
                throw new PollServiceException("Poll #" + pollId + " does not exist.");
            }
            if (poll.status() != PollStatus.OPEN) {
                throw new PollServiceException("Poll #" + pollId + " is not in OPEN state.");
            }

            try (Connection connection = databaseManager.getConnection()) {
                connection.setAutoCommit(false);
                try {
                    pollDao.updatePollStatus(connection, pollId, PollStatus.CLOSED);
                    auditEventDao.insertPollEvent(
                            connection,
                            pollId,
                            "POLL_CLOSED",
                            "actor=" + actor + ";poll_id=" + pollId + ";from=OPEN;to=CLOSED"
                    );
                    connection.commit();
                } catch (Exception e) {
                    connection.rollback();
                    throw e;
                } finally {
                    connection.setAutoCommit(true);
                }
            }
        } catch (PollServiceException e) {
            throw e;
        } catch (Exception e) {
            throw new PollServiceException("Failed to close poll #" + pollId, e);
        }
    }

    private String generateParticipationSecret() {
        byte[] bytes = new byte[32];
        SECURE_RANDOM.nextBytes(bytes);
        return HexFormat.of().formatHex(bytes);
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public PlatformAdapter getPlatformAdapter() {
        return platformAdapter;
    }

    public Logger getLogger() {
        return logger;
    }
}